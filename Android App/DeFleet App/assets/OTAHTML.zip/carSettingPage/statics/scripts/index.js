(function ($, bind) {

    var cmds = controller.getCommands(),
        viewContainer = $('#main'), // 视图总容器
        viewFailed = $('#failBox'), // 失败视图
        viewSuccess = $('#successBox'), // 成功视图
        equipmentStatus = $('#equipmentStatus'),    // 失败状态容器
//        manuallyView = $('#doControl'), // 手动控制界面
        eleAutoLock = $('#autoLock'),  //自动落锁开关
        //eleManually = $('#Manually'),   // 手动控制中转按钮
        optionItems = $('#controlEnter li', true),
//        manuallyButtons = $('#btnList .btn', true), // 手动控制按钮
        supports,
        data = controller.data;

    /**
     * 判断是否支持自动落锁功能
     * @returns {boolean}
     */
    function supportAutoLock() {
        return cmds.slice(0, 2).every(function (cmd) {
            return supports.indexOf(cmd) > -1;
        });
    }

    /**
     * 判断是否支持手动控制功能
     * @returns {boolean}
     */
    function supportManually() {
        return !cmds.slice(2).every(function (cmd) {
            return !(supports.indexOf(cmd) > -1);
        });
    }

    /**
     * 启用或禁用自动落锁开关
     * @param  {boolean} enable
     */
    function enableAutoLock(enable) {
        var option = optionItems[0];
        if (enable) {
            // 设置开关初始状态
            eleAutoLock.checked = controller.getAutoLockState();
            bind(eleAutoLock, 'change', function () {
                // 根据开关变化执行自动落锁
                controller.setAutoLockState(this.checked);
            });
            option.style.display = 'block';
        } else {
            option.style.display = 'none';
        }
    }

    /**
     * 启用或禁用手动控制
     * @param {boolean} enable
     */
    function enableManually(enable) {
        var option = optionItems[1];
        if (enable) {
        	var currentUrl = window.location.href,
	        	urlArr = currentUrl.split("/"),
	        	targetUrl = "", // 手动控制页面URL
	        	targetTitle = "控制页面"; // 手动控制页面Title
            
            urlArr.splice(0,3);
        	urlArr.pop();
        	
            if(urlArr.length){
            	targetUrl = window.location.protocol+"//"+window.location.host+"/"+urlArr.join("/") + "/control.html";
            }else{
            	targetUrl = window.location.protocol+"//"+window.location.host+ "/control.html";
            }
        	
        	bind(option, 'click', function () {
                // todo:显示手动控制界面
            	controller.openWebPage(targetUrl, targetTitle, "");
            });
        	
        	var url = location.search; //获取url中"?"符后的字串
            var theRequest = {};
            if (url.indexOf("?") != -1) {
                var str = url.substr(1);
                var strs = str.split("&");
                for(var i = 0; i < strs.length; i ++) {
                    theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
                }
            }

            //获取参数direct
            if (theRequest.direcet && theRequest.direcet == "true") {
                controller.openWebPage(targetUrl, targetTitle);
            }
        } else {
            option.style.display = 'none';
        }
    }

    /**
     * 初始化失败界面
     * @param {number} errId 失败标识  20-未连接设备  22-不是专车专用固件  21-不支持任何功能
     */
    function initFailedView(errId) {
    	viewContainer.className = "mainFail";
        switch (errId) {
            case 20:
                // todo
            	equipmentStatus.className = "statusA";
                break;
            case 21:
                // todo
            	equipmentStatus.className = "statusB";
                break;
            case 22:
                // todo
            	equipmentStatus.className = "statusC";
                break;
        }
        // todo:显示失败界面
    }

    /**
     * 初始化支持界面
     */
    function initSuccessView() {
        enableAutoLock(supportAutoLock());
        enableManually(supportManually());
        // todo:显示界面
        viewContainer.className = "mainSuccess";
    }

    if (controller.isDeviceConnected()) {
        if (controller.isSpecialFW()) {
            supports = controller.isSupport();
            if (supports.length) {
                // 初始化支持界面
                initSuccessView();
            } else {
                // todo:显示不支持专车专用功能（调用initFailedView）
            	initFailedView(21);
            }
        } else {
            // todo:显示固件不支持（调用initFailedView）
        	initFailedView(22);
        }
    } else {
        // todo:显示设备未连接（调用initFailedView）
    	initFailedView(20);
    }
	/*alert(window.devicePixelRatio);*/
})(function (selector, isAll) {
    if (isAll) {
        return Array.prototype.slice.call(document.querySelectorAll(selector));
    } else {
        return document.querySelector(selector);
    }
}, function (ele, evtName, fun) {
    ele.addEventListener(evtName, fun, false);
});
