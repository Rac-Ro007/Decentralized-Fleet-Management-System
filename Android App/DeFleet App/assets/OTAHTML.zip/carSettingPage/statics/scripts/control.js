/**
 * 车辆控制
 */ 
(function ($, bind) {
	var manuallyView = $('#doControl'), // 手动控制界面
		manuallyButtons = $('#btnList .btn', true), // 手动控制按钮
		supports = controller.isSupport(),
		data = controller.data;
	
	/**
     * 初始化手动控制界面
     */
    manuallyButtons.forEach(function (btn) {
        if (supports.indexOf(data(btn, 'action')) > -1) {
            // todo:按钮可用(分别设置class和data-enabled)
        	btn.className = "btn";
        	data(btn, 'enabled', "true");
        } else {
            // todo:按钮不可用(分别设置class和data-enabled)
        	btn.className = "btn btnDisabled";
        	data(btn, 'enabled', "false");
        }
    });
    bind(manuallyView, 'click', function (evt) {
        var src = evt.srcElement,
            action;
        if (src.tagName === 'A' && data(src, 'enabled') === 'true' && (action = data(src, 'action'))) {
        	// 执行控制命令
            controller.execute(action);
        }
    });
    
    // 是否支持触摸事件  
    var isSupportTouch = 'ontouchstart' in window || "ontouchend" in window.document;  
    // 支持触摸式使用相应的事件替代  
    var hightEvent_in  = isSupportTouch ? 'touchstart': 'mouseover',  
        hightEvent_out = isSupportTouch ? 'touchend' : 'mouseout';  
    
    //绑定active效果
    bind(manuallyView, hightEvent_in, function (evt) {
    	var src = evt.srcElement;
    	if (src.tagName === 'A' && data(src, 'enabled') === 'true') {
        	// 执行控制命令
            src.className = "btn btnOn";
            setTimeout(function() {
            	src.className = "btn btnOff";
            }, 500);
        }	
    });
    
    bind(manuallyView, hightEvent_out, function (evt) {
    	var src = evt.srcElement;
    	if (src.tagName === 'A' && data(src, 'enabled') === 'true') {
        	// 执行控制命令
            src.className = "btn btnOff";
        }	
    });

	/**
	 * 调用接口8，告诉客户端，当前展示的页面是车辆控制界面
	 */
	controller.isCarControllerPage();

})(function (selector, isAll) {
    if (isAll) {
        return Array.prototype.slice.call(document.querySelectorAll(selector));
    } else {
        return document.querySelector(selector);
    }
}, function (ele, evtName, fun) {
    ele.addEventListener(evtName, fun, false);
});
