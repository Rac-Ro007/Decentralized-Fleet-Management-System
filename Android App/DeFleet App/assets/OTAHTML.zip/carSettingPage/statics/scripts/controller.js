var controller = (function () {
    var commands = [
            'AT@S1',	//打开行车自动落锁功能
            'AT@S0',	//关闭行车自动落锁功能
            'AT@STS010101',	//实现开窗功能
            'AT@STS010102',	//实现关窗功能
            'AT@STS020101',	//实现前车门开锁功能    只是前门锁吗？需要找产品确认一下
            'AT@STS020102',	//实现前车门关锁功能
            'AT@STS010501', //实现开天窗功能
            'AT@STS010502'  //实现关天窗功能
        ],
        obd = mapbar.getOBD(),
        app = mapbar.getApp();

    /*commands.forEach(function (str) {
        commands[str] = str;
    });*/


    return {
        /**
         * 获取所有命令
         * @returns {Array.<string>}
         */
        getCommands : function () {
            return commands.concat();
        },

        /**
         * 判断是否支持指定的功能
         * @param {string} [fun] 功能标识 不传递参数时将检测所有功能，并返回支持的功能标识数据
         * @returns {boolean|Array}
         */
        isSupport: function (fun) {
            if (fun) {
                return obd.isCommandSupport(fun);
            } else {
                return commands.filter(function (fun) {
                    return obd.isCommandSupport(fun);
                });
            }
        },

        /**
         * 执行车辆控制命令
         * @param {string} cmd 命令标识
         */
        execute: function (cmd) {
            obd.executeCommand(cmd);
        },

        /**
         * 获取自动落锁设置状态
         * @returns {boolean} true 已打开   false 已关闭
         */
        getAutoLockState: function () {
            return obd.getAutoLockState();
        },

        /**
         * 设置自动落锁状态
         * @param {boolean} [state=true]
         */
        setAutoLockState: function (state) {
            state = typeof state === 'boolean' ? state : true;
            obd.setAutoLockState(state);
        },

        /**
         * OBD设备是否连接
         * @returns {boolean}
         */
        isDeviceConnected: function () {
            return obd.getDeviceConnectionState();
        },

        /**
         * OBD设备是否为专车专用固件
         * @returns {boolean}
         */
        isSpecialFW: function () {
            return obd.isSpecialCarFW();
        },
        /**
         * 页面跳转
         * @returns
         */
        openWebPage: function (url, title, data) {
            return app.openWebPage(url, title, data);
        },
        /**
         * 读取或设置指定元素的私有数据
         * @param {HTMLElement} ele DOM元素
         * @param {string} key 键名
         * @param {string} [value] 数据值，省略时读取，否则设置
         * @returns {string|HTMLElement}
         */
        data: function (ele, key, value) {
            if (ele.nodeType !== 1) {
                return null;
            }
            if (ele.dataset) {
                data = function (ele, key, value) {
                    if (ele.nodeType !== 1) {
                        return ele;
                    }
                    if (value) {
                        ele.dataset[key] = value;
                        return ele;
                    } else {
                        return ele.dataset[key];
                    }
                };
            } else {
                data = function (ele, key, value) {
                    if (ele.nodeType !== 1) {
                        return ele;
                    }
                    if (value) {
                        ele.setAttribute('data-' + key, value);
                        return ele;
                    } else {
                        return ele.getAttribute('data-' + key);
                    }
                };
            }
            return data(ele, key, value);
        },
		/**
		 * 调用接口8，告诉客户端，当前展示的页面是车辆控制界面
		 */
		isCarControllerPage: function () {
			return obd.isCarControllerPage();
		}
    }
})();

(function (doc, win) {
	var docEl = doc.documentElement,
		resizeEvt = 'orientationchange' in window ? 'orientationchange' : 'resize',
		recalc = function () {
			var clientWidth = docEl.clientWidth;
			if (!clientWidth) return;
			docEl.style.fontSize = 20 * (clientWidth / 320) + 'px';
			/*alert(docEl.style.fontSize);*/
		};

	if (!doc.addEventListener) return;
	win.addEventListener(resizeEvt, recalc, false);
	doc.addEventListener('DOMContentLoaded', recalc, false);
})(document, window);