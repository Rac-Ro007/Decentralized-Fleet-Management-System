Path: .
Working Copy Root Path: /home/simba/.jenkins/workspace/NaviCoreAndroidTrunk/branches/5.0.x
URL: svn://192.168.0.5/navigation/navi_core/branches/5.0.x/jnavicore
Repository Root: svn://192.168.0.5/navigation
Repository UUID: c56a160c-d8ec-7641-9537-4717675232d2
Revision: 90265
Node Kind: directory
Schedule: normal
Last Changed Author: zhangxiaopeng
Last Changed Rev: 90238
Last Changed Date: 2015-08-20 20:10:35 +0800 (Thu, 20 Aug 2015)

